D_star_PathPlanning
===================

Simple Matlab implementation of D*Lite, Focussed D*, A*, for dynamic path planning for mobile robots

Based on work:

M. Likhachev, S. Koening : D* Lite, Proceedings of the AAAI Conference of Artificial Intelligence (AAAI)

S. Koening : Fast Replanning for navigation in unknown terrain , Transactions on Robotics

M. Likhachev, S. Koening : Incremental replanning for mapping, Proceedings of the IEEE/RSJ International Conference on Intelligent Robots and Systems (IROS), Vol. 1

A. Stentz : Focussed D*
====================

To run sample, first you have to exectute 'javaclasspath(pwd);'. 
