# UNI_Path_Planning_Simulator
On-line path planning simulator for mobile robots in cluttered environments

Simulation of on-line path planning with A*, Artificial potential fields, rapidly exploring random trees and probabilistic road-map using personalized GUI in matlab.

See article in PDF for detailed information.

Developed by: Francisco J. Garcia R.
2016
